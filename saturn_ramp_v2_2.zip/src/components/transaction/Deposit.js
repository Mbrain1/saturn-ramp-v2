import {useState,useEffect,useContext,useRef} from "react";
import {ContextApi} from "/src/components/ContextApi";
import axios  from "/helpers/axios";
import Step1 from "./deposit/Step1";
import Step2 from "./deposit/Step2";
import Step3 from "./deposit/Step3";
import Step4 from "./deposit/Step4";
import {useRouter} from "next/router";
import { alert, copyText } from "/helpers/toast";
const Deposit = ({ selected, exchangeRate, setSelected}) => {

  const {transactionRef} = useRouter().query;

  const [isOpen,setIsOpen] = useState({step1: false, step2: false, step3: false,step4: false});
  const { transactionData, setTransactionData } = useContext(ContextApi);
  // const [isProceed,setIsProceed] = useState(false);
  // const walletAddressInput = useRef();


  useEffect(() => {
    //Save current exchange rate to user Context
    setTransactionData({
      ...transactionData,
      exchangeRate:exchangeRate
    })

  },[])

  // const validateAddress = () => {
  //   const validAddr = new RegExp("T[A-Za-z0-9]{33}");
  //   return validAddr.test(transactionData.address) && transactionData.address.length == 34 ? true : false;
  // }

  // useEffect(() => {
    
  //       if(validateAddress() && (transactionData.amount/exchangeRate) >= 10) return setIsProceed(true);
         
  //       setIsProceed(false);

  // },[transactionData.amount,transactionData.address])


  // const save = (e) => {

  //       e.preventDefault();

  //       if(transactionData.address.length < 34) return alert("Please insert a valid address",'error');  

  //       if(transactionData.amount/exchangeRate > 100) return alert("Maximum USDT allowed is 100",'error');
        
  //       setTransactionData({...transactionData,loading: true})
    
  //         axios({
  //         method: "GET",
  //         url: `wallet/agents-balance/${(transactionData.amount/exchangeRate)}`,
  //         })
  //         .then((res) => {

  //           setIsOpen({...isOpen,step1: true});

  //           const {data} = res.data;


  //              setTransactionData({
  //                 ...transactionData,
  //                 agent:{
  //                   bank_name: data.bankName == undefined ? "" : data.bankName ,
  //                   account_number: data.accountNumber == undefined ? "" : data.accountNumber ,
  //                   account_name: data.fullname == undefined ? "" : data.fullname ,
  //                   agent_id:data.id == undefined ? "" : data.id ,
  //                   userID: data.userID == undefined ? "" : data.userID ,
  //                   loading: false
  //                }

  //             });
             

             
  //         })
  //         .catch((err) => console.log(err.message));

  // }


  return (
    <>  
          <Step1 
            isOpen={isOpen.step1} 
            setIsOpen={() => {
              setIsOpen({...isOpen,step1: !isOpen.step1})}
            }
            next={() => setIsOpen({...isOpen,step2: !isOpen.step2,step1: !isOpen.step1})} 
          />

          <Step2 
            isOpen={isOpen.step2} 
            setIsOpen={() => {
              setIsOpen({...isOpen,step2: !isOpen.step2})}
            }
            next={() => setIsOpen({...isOpen,step3: !isOpen.step3,step2: !isOpen.step2})}
            />

          <Step3 
            isOpen={isOpen.step3} 
            setIsOpen={() => {
              setIsOpen({...isOpen,step3: !isOpen.step3})}
            }
            next={() => setIsOpen({...isOpen,step4: !isOpen.step4,step3: !isOpen.step3})}
            />

          <Step4 
            isOpen={isOpen.step4} 
            setIsOpen={() => {
              setIsOpen({...isOpen,step4: !isOpen.step4})} 
            }
            />


                    <button 
                      className={`py-10 px-10 rounded-2xl flex flex-col items-center text-center space-y-3 ${selected === "Deposit" ? 'bg-blue-900 ' : 'bg-gray-100'}`} 
                      onClick={() => {
                        setSelected()
                        setIsOpen({...isOpen,step1: !isOpen.step1})
                      }}>

                    <img src={`/assets/svgs/deposit.svg`} />
                     <div className="font-semibold">Deposit</div>
                     <p>Transfer Naira to receive USDT in wallet</p>
                    </button>
        </>
  )
}




export default Deposit;
