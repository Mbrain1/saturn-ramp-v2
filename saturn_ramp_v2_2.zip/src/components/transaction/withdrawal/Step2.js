import {useState,useEffect,useContext} from "react";
import {ContextApi} from "/src/components/ContextApi";
import axios  from "/helpers/axios";
import { alert, copyText } from "/helpers/toast";

const Step2 = ({isOpen,setIsOpen,next}) => {

  const [selected, setSelected] = useState(0);
  const [generateTransactionRef, setGenerateTransactionRef] = useState(Math.floor(1000 + Math.random() * 9000)); //generate Transaction Reference
  const {transactionData,setTransactionData} = useContext(ContextApi);
  

  const handleWithdrawal = (e) => {

          e.preventDefault()

          setTransactionData({...transactionData,loading: true})

          axios({
          method: "POST",
          url: `withdraw-usdt`,
          data: {
              amount: transactionData.withdrawal.usdt,
              fiatAmount: transactionData.withdrawal.amount,
              companyUsdtwallet: transactionData.withdrawal.address,
              customerEmail: transactionData.withdrawal.user.email,
              accountName: transactionData.withdrawal.user.account_name,
              accountNumber: transactionData.withdrawal.user.account_number,
              customerPhone: transactionData.withdrawal.user.mobile_number,
              bankName: transactionData.withdrawal.user.bank_name,
              agentID:  transactionData.agent.agent_id
          }
          })
          .then((res) => {

             setTransactionData({...transactionData,transactionRef: generateTransactionRef,loading: false});
             next();

          })
          .catch((err) => console.log(err.message));


  }

  return (
    <>

      <section className={`modal-wrapper ${isOpen ? 'show-modal' : 'hide-modal'} `}>

      <div className="modal-inner-wrapper">

      <div className="modal-body">
            <header className="space-y-2">
                        <div className="flex justify-between items-center">
                          <h2 className="text-2xl font-bold">Transaction Summary </h2>
                          <button onClick={() => setIsOpen()}><img src="/assets/svgs/times.svg" /></button>
                        </div>
                        <p>Review your payment details before proceeding  </p>
            </header>

            <form className={`grid md:grid-cols-2 gap-4 text-gray-30`} onSubmit={(e) => handleWithdrawal(e)}>
               
                  <div className="form-group">
                      <label>Amount to be withdrawn</label>
                      <h2 className="text-xl font-bold">&#8358;{transactionData.withdrawal.amount - transactionData.exchangeRate}</h2>
                  </div>

                  <div className="form-group">
                      <label>USDT Sent</label>
                      <h2 className="text-xl font-bold">{transactionData.withdrawal.usdt - 1} USDT</h2>
                  </div>

                 {/* {transactionData.agent.bank_name.length === 0 ? 

                     <div className="form-group md:col-span-2 flex flex-col items-center px-10 justify-center text-center">
                         <h1 className="text-xl font-bold">UH-OH, </h1>
                         <p>There is no agent available to proceed with this transaction. Please try again later.</p>
                     </div>
                   :
                  <>*/}

                   <div className="border-t md:col-span-2 border-gray-100 pt-2 w-full font-bold text-black">
                     Banking Information 
                   </div>


                   <div className="form-group">
                      <label>Bank Name</label>
                      <h3 className="font-medium text-lg">{transactionData.withdrawal.user.bank_name}</h3>
                  </div>


                   <div className="form-group">
                      <label>Account Number</label>
                      <button className="font-medium text-lg block" type="button" onClick={() => copyText(transactionData.withdrawal.user.account_number)}>{transactionData.withdrawal.user.account_number} <i className="fas fa-copy"></i></button>
                  </div>

                   <div className="form-group md:col-span-2">
                      <label>Account Name </label>
                      <h3 className="font-medium text-lg">{transactionData.withdrawal.user.account_name}</h3>
                  </div>

                   <div className="border-t md:col-span-2 border-gray-100 pt-2 w-full font-bold text-black">
                     Personal Information 
                   </div>

                   <div className="form-group">
                      <label>Email</label>
                      <h3 className="font-medium text-lg">{transactionData.withdrawal.user.email}</h3>
                  </div>

                   <div className="form-group">
                      <label>Mobile Number </label>
                      <h3 className="font-medium text-lg">{transactionData.withdrawal.user.mobile_number}</h3>
                  </div>

                   <div className="form-group">
                      <label>Account Name  </label>
                      <h3 className="font-medium text-lg">{transactionData.withdrawal.user.account_name}</h3>
                  </div>
                 
                
                   <div className="form-group md:col-span-2">
                      <button className="btn w-full bg-blue-900 py-4 rounded-xl" type="submit" >Withdraw</button>
                  </div>
                 {/* </>
               }*/}

            </form>
      </div>
   </div>
  </section>
    </>
  )
}

export default Step2;