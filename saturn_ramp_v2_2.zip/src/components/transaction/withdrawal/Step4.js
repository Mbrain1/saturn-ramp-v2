import {useState,useContext} from "react";
import {ContextApi} from "/src/components/ContextApi";


const Step4 = ({isOpen,setIsOpen}) => {

  const [selected, setSelected] = useState(0);
  const {transactionData,setTransactionData} = useContext(ContextApi);
  
  return (
    <>

     <section className={`modal-wrapper ${isOpen ? 'show-modal' : 'hide-modal'} `}>

      <div className="modal-inner-wrapper">

      <div className="modal-body">
            <header className="space-y-2">
                        <div className="flex justify-end items-center">
                          <button onClick={() => setIsOpen()}><img src="/assets/svgs/times.svg" /></button>
                        </div>
                       
            </header>

            <div className={`flex flex-col justify-center items-center text-center space-y-5`}>
                <img src="/assets/svgs/checked.svg" className="w-5" />
                <div className="font-bold text-3xl text-blue-900">Withdrawal Successful!</div>
               <p className="text-lg">Your account has been credited with N{transactionData.withdrawal.amount}</p>
            </div>
      </div>
    </div>
  </section>
    </>
  )
}

export default Step4;