import {useState,useEffect,useContext} from "react";
import {ContextApi} from "/src/components/ContextApi";
import axios  from "/helpers/axios";
import { alert, copyText } from "/helpers/toast";

const Step3 = ({isOpen,setIsOpen,next}) => {

  const [selected, setSelected] = useState(0);
  const [countDown, setCountDown] = useState(30);
  const {transactionData,setTransactionData} = useContext(ContextApi);
  
   const copyTransactionLink = () => {

    const textField = window.location.hostname + '/verify/' + //Transaction link 
    transactionData.transactionRef + '?id=' + 
    transactionData.agent.userID + '&amount=' +
    transactionData.amount; 

    copyText(textField)

    transactionData.transactionStatus ? next() : null; //Move to next screen if transaction status is successful
  }


  useEffect(() => {

    if(!isOpen){
      setTransactionData({...transactionData,loading:false});
    }

  },[isOpen]);



  // useEffect(() => {

  //   if(transactionData.transactionStatus || transactionData.transactionRef.length == 0 || !isOpen) return;  //If status is true, then dont execute this code anymore

  //  const countDownTimer  = setInterval(() => setCountDown((prevCounter) => prevCounter <= 0 ? 30 : --prevCounter),1000)

  //   const refresh  = setInterval(() => {
  //       setTransactionData({...transactionData,loading: true})
  //        axios({
  //         method: "POST",
  //         url: `verify-payments`,
  //         data: {
  //           referenceID : transactionData.transactionRef,
  //           agentmonoID : transactionData.agent.userID,
  //           amount : transactionData.amount
  //         }
  //         })
  //         .then((res) => {

  //            setTransactionData({...transactionData,transactionStatus: res.data.data.paymentStatus != 'Failed' ? true : false,loading:false})

  //         })
  //         .catch((err) => console.log(err.message));


  //   },30000);


  //   return  () => {
  //       clearInterval(refresh);
  //       clearInterval(countDownTimer);
  //     }


  // },[transactionData.transactionRef,transactionData.transactionStatus,isOpen])




  return (
    <>

    <section className={`modal-wrapper ${isOpen ? 'show-modal' : 'hide-modal'} `}>

      <div className="modal-inner-wrapper">

      <div className="modal-body">
            <header className="space-y-2">
                        <div className="flex justify-between items-center">
                          <h2 className="text-2xl font-bold">Transaction Progress  </h2>
                          <button onClick={() => setIsOpen()}><img src="/assets/svgs/times.svg" /></button>
                        </div>
                        <p>keep this page open or copy this link to check transaction status</p>
            </header>

            <form className={`grid grid-cols-1 text-gray-30`}>
                  

                   {!transactionData.transactionStatus &&
                   <div className="flex justify-end  font-medium text-gray-300 mb-2">
                    <span className="text-sm">Transaction Status will refresh in {countDown} seconds</span>
                  </div>
              }


                  <div className={`form-group border-l-2 px-5  pb-6 after:content-[''] after:w-4 after:h-4 ${!transactionData.transactionStatus ? 'border-blue-900 after:bg-blue-900' : 'after:bg-gray-800 border-stone-300' } after:rounded-full after:absolute after:-left-2 after:top-0`}>
                      <h3 className="text-lg text-gray-20 font-bold">{transactionData.withdrawal.usdt} USDT sent to wallet Address</h3>
                      <div className={`text-lg  font-medium text-gray-100`}>{transactionData.withdrawal.address}</div>
                      <div className={`text-sm font-semibold ${!transactionData.transactionStatus && 'text-blue-900'}`}>Pending</div>
           
                  </div>

                 


                  <div className={`form-group border-l-2 px-5 pb-6 after:content-[''] after:w-4 after:h-4  after:rounded-full after:absolute after:-left-2 after:top-0 ${transactionData.transactionStatus ? 'border-blue-900 after:bg-blue-900' : 'after:bg-gray-800 border-stone-300' }`}>
                      <h3 className={`text-lg text-gray-20 font-bold`}>USDT Received</h3>
                      <div className={`text-sm font-semibold  ${transactionData.transactionStatus && 'text-blue-900'}`}>Done</div>
                  </div>

                  <div className={`form-group border-l-2 px-5 pb-6 after:content-[''] after:w-4 after:h-4  after:rounded-full after:absolute after:-left-2 after:top-0 ${transactionData.transactionStatus ? 'border-blue-900 after:bg-blue-900' : 'after:bg-gray-800 border-stone-300' }`}>
                      <h3 className={`text-lg text-gray-20 font-bold`}>Naira Sent</h3>
                      <div className={`text-sm font-semibold  ${transactionData.transactionStatus && 'text-blue-900'}`}>Done</div>
                  </div>

                   <div className={`form-group border-l-2 px-5  pb-6 after:content-[''] after:w-4 after:h-4 after:rounded-full after:absolute after:-left-2 after:top-0     before:content-[''] before:w-4 before:h-full before:bg-white  before:absolute before:-left-2 before:top-0  ${transactionData.transactionStatus ? 'border-blue-900 after:bg-blue-900' : 'after:bg-gray-800 border-stone-300' }`}>
                      <h3 className={`text-lg text-gray-20 font-bold`}>Your account has been credited with N{transactionData.withdrawal.amount - transactionData.exchangeRate}</h3>
                  </div>


                
                   <div className="form-group mt-5 flex space-x-5">
                    <button 
                        className={`btn w-full bg-blue-900 py-3 rounded-xl`}
                        type="button" 
                        onClick={() => {}}>I have received the Naira Amount</button>

                      <button 
                        className={`btn w-full text-blue-900 shadow-lg bg-blue-600 py-3 rounded-xl`}
                        type="button" 
                        onClick={() => copyTransactionLink()}>Copy Transaction link</button>
                  </div>
            </form>
      </div>
    </div>
  </section>
    </>
  )
}

export default Step3;