import {useState,useEffect,useContext} from "react";
import {ContextApi} from "/src/components/ContextApi";
import { useForm } from 'react-hook-form';
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup"
import { copyText } from "/helpers/toast";

const Step1 = ({isOpen,setIsOpen,next}) => {

  const [selected, setSelected] = useState(0);
  const { transactionData, setTransactionData } = useContext(ContextApi);

 const schema = yup.object({
  ['Bank name'] : yup.string().required(),
  ['Account Name'] : yup.string().required(),
  ['Account Number'] : yup.string().required().min(5),
  ['Mobile Number'] : yup.string().required().min(9),
  ['Email'] : yup.string().required().email(),
 })

  const { register, handleSubmit, formState: { errors } } = useForm({
    resolver : yupResolver(schema)
  });

  const handleWithdrawal = (data) => {
     next()
  }

  return (
    <>
      <section className={`modal-wrapper ${isOpen ? 'show-modal' : 'hide-modal'} `}>

      <div className="modal-inner-wrapper">

      <div className="modal-body">
            <header className="space-y-2">
                        <div className="flex justify-between items-center">
                          <h2 className="text-2xl font-bold">Withdrawal Summary </h2>
                          <button onClick={() => setIsOpen()}><img src="/assets/svgs/times.svg" /></button>
                        </div>
                        <p>Enter amount you want to withdraw </p>
            </header>

            <form className={`grid md:grid-cols-2 gap-4 text-gray-30`} onSubmit={handleSubmit(handleWithdrawal)}>
               
                  <div className="form-group">
                      <label>Amount you will recieve </label>
                      <input disabled type="text" className="cursor-not-allowed form-control py-2 font-medium  bg-gray-50  text-gray-30 border text-right " defaultValue={transactionData.withdrawal.amount - transactionData.exchangeRate}  />
                      <div className="absolute top-8 left-3 font-medium  flex justify-center items-center space-x-2 text-gray-30">
                        <img src="/assets/svgs/ng.svg" /> 
                        <span>NGN</span>
                      </div>
                  </div>

                  <div className="form-group">
                      <label>USDT Amount</label>
                      <input disabled type="text" className="cursor-not-allowed form-control py-2 font-medium  bg-gray-50  text-gray-30 border text-right" defaultValue={transactionData.withdrawal.usdt - 1} />
                      <div className="absolute top-8 left-3 font-medium  flex justify-center items-center space-x-2 text-gray-30">
                        <img src="/assets/svgs/usdt.svg" /> 
                        <span>USDT</span>
                      </div>
                      <p className="text-xs text-green-500">
                         Commission Fee: 1 USDT
                      </p>
                  </div>

                  <div className="form-group md:col-span-2">
                      <label>Agent USDT wallet address (TRC-20)</label>
                      <input disabled type="text" className="cursor-not-allowed form-control py-2 font-medium  bg-gray-50  text-gray-30 border " defaultValue={transactionData.withdrawal.address} />
                      <button type="button" className="absolute right-2 bottom-3 text-blue-900 text-sm" onClick={() => copyText(transactionData.withdrawal.address)}>Copy</button>
                  </div>

                   <div className="border-t md:col-span-2 border-gray-100 pt-2 w-full font-bold text-black">
                     Banking Information
                   </div>


                  <div className="form-group">
                      <label>Bank Name </label>
                      <input 
                        type="text" 
                        className="form-control py-2 font-medium  bg-gray-50  text-gray-30 border"
                        {...register('Bank name')}
                        onChange={(e) => setTransactionData({
                            ...transactionData,
                            withdrawal : {
                              ...transactionData.withdrawal,
                               user : {
                                ...transactionData.withdrawal.user,
                                bank_name: e.target.value
                              }
                            }
                          })} 
                        />
                      <p className="error">{errors['Bank name']?.message}</p>
                  </div>

                  <div className="form-group">
                      <label>Account Number </label>
                      <input 
                        type="text" 
                        {...register('Account Number')}
                        className="form-control py-2 font-medium  bg-gray-50  text-gray-30 border"
                        onChange={(e) => setTransactionData({
                            ...transactionData,
                            withdrawal : {
                              ...transactionData.withdrawal,
                               user : {
                                ...transactionData.withdrawal.user,
                                account_number: e.target.value
                              }
                            }
                          })} 
                        />
                        <p className="error">{errors['Account Number']?.message}</p>
                  </div>


                   <div className="form-group">
                      <label>Account Name </label>
                      <input 
                        type="text" 
                        {...register('Account Name')}
                        className="form-control py-2 font-medium  bg-gray-50  text-gray-30 border"
                        onChange={(e) => setTransactionData({
                            ...transactionData,
                            withdrawal : {
                              ...transactionData.withdrawal,
                              user : {
                                ...transactionData.withdrawal.user,
                                account_name: e.target.value
                              }
                            }
                          })} 
                        />
                        <p className="error">{errors['Account Name']?.message}</p>
                  </div>

                  <div className="border-t md:col-span-2 border-gray-100 pt-2 w-full font-bold text-black">
                     Personal Information 
                   </div>

                     <div className="form-group">
                      <label>Email </label>
                      <input 
                        type="text" 
                        {...register('Email')}
                        className="form-control py-2 font-medium  bg-gray-50  text-gray-30 border"
                        onChange={(e) => setTransactionData({
                            ...transactionData,
                            withdrawal : {
                              ...transactionData.withdrawal,
                             user : {
                                ...transactionData.withdrawal.user,
                                 email: e.target.value
                              }
                            }
                          })} 
                        />
                        <p className="error">{errors['Email']?.message}</p>
                  </div>

                  <div className="form-group">
                      <label>Mobile  Number </label>
                      <input 
                        type="text" 
                        {...register('Mobile Number')}
                        className="form-control py-2 font-medium  bg-gray-50  text-gray-30 border"
                        onChange={(e) => setTransactionData({
                            ...transactionData,
                            withdrawal : {
                              ...transactionData.withdrawal,
                              user : {
                                ...transactionData.withdrawal.user,
                                 mobile_number: e.target.value
                              }
                            }
                          })} 
                        />
                        <p className="error">{errors['Mobile Number']?.message}</p>
                  </div>

                
                   <div className="form-group md:col-span-2">
                      <button className="btn w-full bg-blue-900 py-4 rounded-xl" type="submit">Continue</button>
                  </div>
                 
            </form>
      </div>
    </div>
  </section>
    </>
  )
}

export default Step1;