import {useState,useEffect,useContext} from "react";
import {ContextApi} from "/src/components/ContextApi";
import axios  from "/helpers/axios";
import { alert, copyText } from "/helpers/toast";

const Step2 = ({isOpen,setIsOpen,next}) => {

  const [selected, setSelected] = useState(0);
  const [generateTransactionRef, setGenerateTransactionRef] = useState(Math.floor(1000 + Math.random() * 9000)); //generate Transaction Reference
  const {transactionData,setTransactionData} = useContext(ContextApi);



  const handleTransaction = () => {

          setTransactionData({...transactionData,loading: true})

          axios({
          method: "POST",
          url: `customer`,
          data: {
              amount: transactionData.usdt,
              fiatAmount: transactionData.amount,
              customerEmail: transactionData.email,
              reference: generateTransactionRef,
              accountName: transactionData.agent.account_name,
              accountNumber: transactionData.agent.account_number,
              bankName: transactionData.agent.bank_name,
              majorExchange: transactionData.major_exchange, 
              agentID:  transactionData.agent.agent_id,
              customerUsdtwallet: transactionData.address
          }
          })
          .then((res) => {

             setTransactionData({...transactionData,transactionRef: generateTransactionRef,loading: false});
             next();

          })
          .catch((err) => console.log(err.message));


  }

  return (
    <>

      <section className={`modal-wrapper ${isOpen ? 'show-modal' : 'hide-modal'} `}>

      <div className="modal-inner-wrapper">

      <div className="modal-body">
            <header className="space-y-2">
                        <div className="flex justify-between items-center">
                          <h2 className="text-2xl font-bold">Transaction Summary </h2>
                          <button onClick={() => setIsOpen()}><img src="/assets/svgs/times.svg" /></button>
                        </div>
                        <p>Review your payment details before proceeding  </p>
            </header>

            <form className={`grid md:grid-cols-2 gap-5 text-gray-30`}>
               
                  <div className="form-group">
                      <label>Amount  to send </label>
                      <input type="text" disabled className="cursor-not-allowed form-control py-2 font-bold  bg-gray-50  text-gray-30 border pl-24 " defaultValue={transactionData.amount}  />
                      <div className="absolute top-8 left-3 font-medium  flex justify-center items-center space-x-2 text-gray-30">
                        <img src="/assets/svgs/ng.svg" /> 
                        <span>NGN</span>
                      </div>
                  </div>

                  <div className="form-group">
                      <label>Your wallet will receive</label>
                      <input type="text" disabled className="cursor-not-allowed form-control py-2 font-bold  bg-gray-50  text-gray-30 border pl-24" defaultValue={(transactionData.usdt - 1).toFixed(2)} />
                      <div className="absolute top-8 left-3 font-medium  flex justify-center items-center space-x-2 text-gray-30">
                        <img src="/assets/svgs/usdt.svg" /> 
                        <span>USDT</span>
                      </div>
                      <p className="text-xs text-green-500">
                         Commission Fee: 1 USDT
                      </p>
                  </div>

                   <div className="border-t md:col-span-2 border-gray-100 w-full"></div>

                  {transactionData.agent.bank_name.length === 0 ? 

                     <div className="form-group md:col-span-2 flex flex-col items-center px-10 justify-center text-center">
                      <h1 className="text-xl font-bold">UH-OH, </h1>
                      <p>There is no agent available to proceed with this transaction. Please try again later.</p>
                  </div>
                    :
                  <>

                   <div className="form-group">
                      <label>Bank Name</label>
                      <h3 className="font-medium text-lg">{transactionData.agent.bank_name}</h3>
                  </div>


                   <div className="form-group">
                      <label>Account Number</label>
                      <button className="font-medium text-lg block" type="button" onClick={() => copyText(transactionData.agent.account_number)}>{transactionData.agent.account_number} <i className="fas fa-copy"></i></button>
                  </div>

                   <div className="form-group md:col-span-2">
                      <label>Account Name </label>
                      <h3 className="font-medium text-lg">{transactionData.agent.account_name}</h3>
                  </div>


                   <div className="form-group md:col-span-2 space-y-2">
                      <h3 className="font-medium text-lg">Narration</h3>
                      <p className="text-sm">Use this code as reference/narration in other to accelerate payment confirmation</p>

                      
                      <div className="flex justify-start items-center space-x-1 md:space-x-3 ">

                      {String(generateTransactionRef).split("").map((item,index) =>

                          <input
                             key={index} 
                             type="text" 
                             className="form-control py-3 w-12 h-12 px-4 font-bold text-lg  bg-gray-50  text-gray-30 border" 
                             defaultValue={item} 
                           />

                        )}
                         
                         <button className="btn bg-blue-600 font-normal text-blue-900 w-auto h-12 px-2 text-center inline-block rounded-xl text-xs" type="button" onClick={() => copyText(generateTransactionRef)}>Copy Code</button>
                      </div>
                     
                  </div>

                 
                
                   <div className="form-group md:col-span-2">
                      <button className="btn w-full bg-blue-900 py-5 rounded-xl" type="button" onClick={() => handleTransaction()}>I have made the transfer</button>
                  </div>
                  </>
                }
            </form>
         </div>
      </div>
  </section>
    </>
  )
}

export default Step2;