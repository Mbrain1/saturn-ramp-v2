import {useState} from "react";
import Deposit from "./Deposit";
import Withdrawal from "./Withdrawal";

const Home = ({exchangeRate}) => {

  const [selected,setSelected] = useState('Deposit');

  return (
    <>
    <aside className="lg:px-10  z-50 w-full md:w-3/5 text-xl text-white space-y-5 pt-5">

                <h2 className="text-center relative after:w-14 after:absolute after:h-1 after:rounded-lg after:bg-white after:left-[45%] after:-top-6 text-medium">What would you like to do? </h2>
                <nav className="grid md:grid-cols-2 gap-5">
                  <Deposit  setSelected={() => setSelected('Deposit')} selected={selected} exchangeRate={exchangeRate} />

                  <Withdrawal  setSelected={() => setSelected('Withdrawal')} selected={selected} exchangeRate={exchangeRate}  />

                </nav>
               
               
                
              </aside>
    </>
  )
}



export default Home;
