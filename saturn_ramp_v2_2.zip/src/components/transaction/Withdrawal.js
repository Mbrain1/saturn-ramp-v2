import {useState,useEffect,useContext,useRef} from "react";
import {ContextApi} from "/src/components/ContextApi";
import axios  from "/helpers/axios";
import Step1 from "./withdrawal/Step1";
import Step2 from "./withdrawal/Step2";
import Step3 from "./withdrawal/Step3";
import Step4 from "./withdrawal/Step4";
import {useRouter} from "next/router";
import { alert, copyText } from "/helpers/toast";


const Withdrawal = ({ selected, exchangeRate, setSelected }) => {

  const {transactionRef} = useRouter().query;

  const [isOpen,setIsOpen] = useState({step1: false, step2: false, step3: false,step4: false});
  const {transactionData,setTransactionData,initialTransactionData} = useContext(ContextApi);
  const [isProceed,setIsProceed] = useState(false);
  const walletAddressInput = useRef();


  useEffect(() => {
    //Save current exchange rate to user Context
    setTransactionData({
      ...transactionData,
      exchangeRate:exchangeRate,
      withdrawal:{ 
        ...transactionData.withdrawal,
        amount: (transactionData.withdrawal.usdt*exchangeRate).toFixed(2)
      }
    })

  },[transactionData.withdrawal.amount,transactionData.withdrawal.address])


  useEffect(() => {
    axios({
          method: "GET",
          url: `mass-collection-address`,
          })
          .then((res) => {
            const {data} = res.data;
                
               setTransactionData({
                            ...transactionData,
                            withdrawal : {
                              ...transactionData.withdrawal,
                              address: data.walletaddress
                            }
                    })

               walletAddressInput.current.value = data.walletaddress
             
          })
          .catch((err) => console.log(err.message));
  },[])

  useEffect(() => {
    
        if(transactionData.withdrawal.address.length >= 34 && (transactionData.withdrawal.amount/exchangeRate) >= 10) {
          setIsProceed(true);
          return;
        }            
    
      setIsProceed(false);

  },[transactionData.withdrawal.amount,transactionData.withdrawal.address])


  const resetData = () => {
    // setTransactionData(initialTransactionData);//reset transaction Data here
    // walletAddressInput.current.value = "";
  }

  const save = (e) => {

        e.preventDefault();


        if(transactionData.withdrawal.address.length < 34) return alert("Please insert a valid address",'error');

        if(transactionData.withdrawal.usdt > 100) return alert("Maximum USDT allowed is 100",'error');

        setIsOpen({...isOpen,step1: true});

  }


  return (
    <>  
          <Step1 
            isOpen={isOpen.step1} 
            setIsOpen={() => {
              resetData();
              setIsOpen({...isOpen,step1: !isOpen.step1})}
            }
            next={() => setIsOpen({...isOpen,step2: !isOpen.step2,step1: !isOpen.step1})} 
          />

          <Step2 
            isOpen={isOpen.step2} 
            setIsOpen={() => {
              resetData();
              setIsOpen({...isOpen,step2: !isOpen.step2})}
            }
            next={() => setIsOpen({...isOpen,step3: !isOpen.step3,step2: !isOpen.step2})}
            />

          <Step3 
            isOpen={isOpen.step3} 
            setIsOpen={() => {
              resetData();
              setIsOpen({...isOpen,step3: !isOpen.step3})}
            }
            next={() => setIsOpen({...isOpen,step4: !isOpen.step4,step3: !isOpen.step3})}
            />

          <Step4 
            isOpen={isOpen.step4} 
            setIsOpen={() => {
              resetData();
              setIsOpen({...isOpen,step4: !isOpen.step4})} 
            }
            />


           <button 
                      className={`py-10 px-10 rounded-2xl flex flex-col items-center text-center space-y-3 ${selected === "Withdrawal" ? 'bg-blue-900 ' : 'bg-gray-100'}`} 
                      onClick={() => setSelected()}>

                    <img src={`/assets/svgs/withdrawal.svg`} />
                     <div className="font-semibold">Withdrawal</div>
                     <p>Transfer Naira to receive USDT in wallet</p>
                    </button>
    </>
  )
}




export default Withdrawal;
