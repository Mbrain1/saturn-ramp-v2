import Link from "next/link";
export default function Navbar() {
    return (
        <>
        
        <header className="bg-blue-500 py-10">
           <nav className="container flex justify-between items-center text-white text-lg font-medium">
               <Link href="/"><a><img src="/assets/images/logo/logo3.png" /></a></Link>

               <ul className="flex items-center space-x-10">
                   <li><Link href="/">How It Works</Link></li>
                   <li><Link href="/">FAQS</Link></li>
                   <li><Link href="/">Contact</Link></li>
               </ul>
           </nav>
        </header>
        </>
      )
}