import {useState,useEffect,useContext} from "react";
import {ContextApi} from "/src/components/ContextApi";
import { useForm } from 'react-hook-form';
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup"

const exchange = [{image:'ftx.png',title:'FTX'},{image:'okex.png',title:'OKEX'},{image:'binance.png',title:'Binance'},{image:'kucoin.png',title:'KuCoin'},{image:'gate.png',title:'Gate.io'},{image:'vibra.png',title:'Vibra'},{image:'beidemand.png',title:'beidemand'}]

const Step1 = ({isOpen,setIsOpen,next}) => {

  const [selected, setSelected] = useState(0);
  const [isProceed,setIsProceed] = useState(false)
  const {transactionData,setTransactionData} = useContext(ContextApi);


  useEffect(() => {
    setTransactionData({...transactionData,major_exchange: exchange[selected].title});
  },[selected])


  useEffect(() => {
        
        if(transactionData.email.trim().length > 0) {
            setIsProceed(true);
            return;
        }            
    

      setIsProceed(false);
    
    
  },[transactionData.email])


 const schema = yup.object({
  ['Email'] : yup.string().required().email(),
 })

  const { register, handleSubmit, formState: { errors } } = useForm({
    resolver : yupResolver(schema)
  });

 

  const handleForm = (data) => {
     next()
  }




  return (
    <>
    <section className={`modal-wrapper ${isOpen ? 'show-modal' : 'hide-modal'} `}>

      <div className="modal-inner-wrapper">

      <div className="modal-body">
            <header className="space-y-2">
                        <div className="flex justify-between items-center">
                          <h2 className="text-2xl font-bold">Deposit Naira</h2>
                          <button onClick={() => setIsOpen()}><img src="/assets/svgs/times.svg" /></button>
                        </div>
                        <p>Enter your email and select an exchange plaform</p>
            </header>

            <form className={`grid grid-cols-2 md:grid-cols-3 gap-4`} onSubmit={handleSubmit(handleForm)}>

               
                  <div className="form-group col-span-2 md:col-span-3">
                      <label>Email</label>
                      <input 
                        type="text" 
                        {...register('Email')}
                        placeholder="Enter Email Address"                        
                        className="form-control font-bold text-2xl bg-gray-400 " 
                        onChange={(e) => setTransactionData({...transactionData,email: e.target.value})}
                          />
                        <p className="error">{errors['Email']?.message}</p>
                  </div>

                  <div className="border-t col-span-2 md:col-span-3 border-gray-100">
                  </div>

                  {exchange.map((item,index) =>
                  <div className="form-group" key={index}>
                      <button 
                        type="button"
                        className={`btn w-full bg-white py-5 md:py-3 px-4 flex justify-start items-center space-x-3 border rounded-xl  ${selected === index ? 'border-blue-900' : 'border-stone-200' }`}
                        onClick={(e) => setSelected(index)} >
                         <img src={`/assets/images/logo/${item.image}`} className="h-5 w-5 md:w-auto md:h-auto" />
                         <div className="text-base md:text-xl text-gray-20 font-bold">{item.title}</div>  
                      </button>
                  </div>
                   )}



                   <div className="form-group col-span-2 md:col-span-3">
                      <label>Other</label>
                      <input 
                        type="text" 
                        placeholder="Enter Exchange Name"   
                        className="form-control font-bold text-2xl bg-gray-400 " 
                        onChange={(e) => setTransactionData({...transactionData,major_exchange: e.target.value})}
                          />
                  </div>


                
                   <div className="form-group col-span-2 md:col-span-3">
                      <button 
                        className={`btn w-full py-5 bg-blue-900`} 
                        type="submit">
                          Continue
                        </button>
                  </div>
            </form>
      </div>
    </div>
  </section>
    </>
  )
}

export default Step1;