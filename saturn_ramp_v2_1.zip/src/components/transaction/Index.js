import {useState} from "react";
import Deposit from "./Deposit";
import Withdrawal from "./Withdrawal";

const Home = ({exchangeRate}) => {

  const [selected,setSelected] = useState('deposit');

  return (
    <>
    <aside className="lg:px-10  z-50 w-full md:w-3/5 text-xl text-white space-y-5 pt-5">

                <h2 className="text-center relative after:w-14 after:absolute after:h-1 after:rounded-lg after:bg-white after:left-[45%] after:-top-6 text-medium">What would you like to do? </h2>
                <nav className="grid grid-cols-2 gap-5">
                  {[{title: 'Deposit',content: 'Transfer Naira to receive USDT in wallet'},{title: 'Withdrawal',content: 'Send USDT to receive Naira in bank account'}].map((item,index) => 
                    <button 
                      key={index} 
                      className={`py-10 px-10 rounded-2xl flex flex-col items-center text-center space-y-3 ${selected === (item.title).toLowerCase() ? 'bg-blue-900 ' : 'bg-gray-100'}`} 
                      onClick={() => setSelected((item.title).toLowerCase())}>

                    <img src={`/assets/svgs/${item.title == 'Deposit' ? 'deposit.svg' : 'withdrawal.svg'}`} />
                     <div className="font-semibold">{item.title}</div>
                     <p>{item.content}</p>
                    </button>)}
                </nav>
               
               {/*<Deposit  selected={selected} exchangeRate={exchangeRate} />*/}

               {/*<Withdrawal  selected={selected} exchangeRate={exchangeRate}  />*/}

                
              </aside>
    </>
  )
}



export default Home;
