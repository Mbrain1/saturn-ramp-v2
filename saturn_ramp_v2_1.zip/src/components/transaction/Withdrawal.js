import {useState,useEffect,useContext,useRef} from "react";
import {ContextApi} from "/src/components/ContextApi";
import axios  from "/helpers/axios";
import Step1 from "./withdrawal/Step1";
import Step2 from "./withdrawal/Step2";
import Step3 from "./withdrawal/Step3";
import Step4 from "./withdrawal/Step4";
import {useRouter} from "next/router";
import { alert, copyText } from "/helpers/toast";


const Withdrawal = ({selected,exchangeRate}) => {

  const {transactionRef} = useRouter().query;

  const [isOpen,setIsOpen] = useState({step1: false, step2: false, step3: false,step4: false});
  const {transactionData,setTransactionData,initialTransactionData} = useContext(ContextApi);
  const [isProceed,setIsProceed] = useState(false);
  const walletAddressInput = useRef();


  useEffect(() => {
    //Save current exchange rate to user Context
    setTransactionData({
      ...transactionData,
      exchangeRate:exchangeRate,
      withdrawal:{ 
        ...transactionData.withdrawal,
        amount: (transactionData.withdrawal.usdt*exchangeRate).toFixed(2)
      }
    })

  },[transactionData.withdrawal.amount,transactionData.withdrawal.address])


  useEffect(() => {
    axios({
          method: "GET",
          url: `mass-collection-address`,
          })
          .then((res) => {
            const {data} = res.data;
                
               setTransactionData({
                            ...transactionData,
                            withdrawal : {
                              ...transactionData.withdrawal,
                              address: data.walletaddress
                            }
                    })

               walletAddressInput.current.value = data.walletaddress
             
          })
          .catch((err) => console.log(err.message));
  },[])

  useEffect(() => {
    
        if(transactionData.withdrawal.address.length >= 34 && (transactionData.withdrawal.amount/exchangeRate) >= 10) {
          setIsProceed(true);
          return;
        }            
    
      setIsProceed(false);

  },[transactionData.withdrawal.amount,transactionData.withdrawal.address])


  const resetData = () => {
    // setTransactionData(initialTransactionData);//reset transaction Data here
    // walletAddressInput.current.value = "";
  }

  const save = (e) => {

        e.preventDefault();


        if(transactionData.withdrawal.address.length < 34) return alert("Please insert a valid address",'error');

        if(transactionData.withdrawal.usdt > 100) return alert("Maximum USDT allowed is 100",'error');

        setIsOpen({...isOpen,step1: true});

  }


  return (
    <>  
          <Step1 
            isOpen={isOpen.step1} 
            setIsOpen={() => {
              resetData();
              setIsOpen({...isOpen,step1: !isOpen.step1})}
            }
            next={() => setIsOpen({...isOpen,step2: !isOpen.step2,step1: !isOpen.step1})} 
          />

          <Step2 
            isOpen={isOpen.step2} 
            setIsOpen={() => {
              resetData();
              setIsOpen({...isOpen,step2: !isOpen.step2})}
            }
            next={() => setIsOpen({...isOpen,step3: !isOpen.step3,step2: !isOpen.step2})}
            />

          <Step3 
            isOpen={isOpen.step3} 
            setIsOpen={() => {
              resetData();
              setIsOpen({...isOpen,step3: !isOpen.step3})}
            }
            next={() => setIsOpen({...isOpen,step4: !isOpen.step4,step3: !isOpen.step3})}
            />

          <Step4 
            isOpen={isOpen.step4} 
            setIsOpen={() => {
              resetData();
              setIsOpen({...isOpen,step4: !isOpen.step4})} 
            }
            />


          <form className={`grid grid-cols-1 md:grid-cols-4 gap-3 lg:px-10 py-10 ${selected !== 'withdrawal' && 'hidden'}`} onSubmit={(e) => save(e)}>

                 <div className="flex justify-between items-center font-medium text-gray-300 md:col-span-4">
                    <span className="text-sm md:text-base text-green-500">1 USDT = NGN {exchangeRate}</span>
                    <span className="text-sm">Rate refreshes in 24hrs</span>
                  </div>

                  
                  <div className="form-group md:col-span-2">
                      <label>USDT Amount</label>
                      <input 
                        type="text" 
                        className="form-control font-bold text-2xl bg-gray-400 text-right " 
                        defaultValue={transactionData.withdrawal.usdt}  
                        onChange={(e) => setTransactionData({
                            ...transactionData,
                            withdrawal : {
                              ...transactionData.withdrawal,
                              usdt : e.target.value
                            }
                          })} 
                      />

                      <span>Minimum amount is 10 USDT</span>
                      <div className="absolute top-11 left-5 text-xl font-bold text-gray-900 flex justify-center items-center space-x-2">
                        <img src="/assets/svgs/usdt.svg" /> 
                        <span>USDT</span>
                      </div>
                  </div>


                  <div className="form-group md:col-span-2">
                      <label>Converted Naira amount </label>
                      <input 
                        type="text" 
                        className="form-control font-bold text-2xl bg-gray-400 text-right" 
                        value={(transactionData.withdrawal.usdt*exchangeRate).toFixed(2)}  
                      />
                      <div className="absolute top-11 left-5 text-xl font-bold text-gray-900 flex justify-center items-center space-x-2">
                        <img src="/assets/svgs/ng.svg" /> 
                        <span>NGN</span>
                      </div>
                  </div>



                  <div className="border-t md:col-span-4 border-gray-100">
                  </div>

                  <div className="form-group md:col-span-3 md:pr-10">
                      <label>Agent USDT wallet address (TRC-20)</label>
                       <input 
                        type="text" 
                        className="form-control font-bold text-2xl  py-4 cursor-not-allowed pr-12" 
                        ref={walletAddressInput}
                        disabled
                       />
                       <button type="button" className="absolute right-2 md:right-14 bottom-6 text-blue-900 text-sm" onClick={() => copyText(transactionData.withdrawal.address)}>Copy</button>
                  </div>

                
                   <div className="form-group md:col-span-1 flex items-end">
                      <button className={`btn w-full  py-5 ${isProceed == false ? 'cursor-not-allowed bg-gray-800' : 'bg-blue-900'} `} type="submit" disabled={!isProceed}>Continue</button>
                  </div>
            </form>
    </>
  )
}




export default Withdrawal;
