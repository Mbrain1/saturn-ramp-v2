import { createContext } from "react";

export const ContextApi = createContext("new Context");